define(
"dojo/cldr/nls/ar/buddhist", //begin v1.x content
{
	"dateFormatItem-yM": "M‏/y G",
	"dateFormatItem-yQ": "Q yyyy",
	"dayPeriods-format-wide-pm": "م",
	"eraNames": [
		"التقويم البوذي"
	],
	"dateFormatItem-MMMEd": "E d MMM",
	"dateFormatItem-yQQQ": "QQQ y",
	"dateFormatItem-MMdd": "dd‏/MM",
	"days-standAlone-wide": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	],
	"dateFormatItem-MMM": "LLL",
	"months-standAlone-narrow": [
		"ي",
		"ف",
		"م",
		"أ",
		"و",
		"ن",
		"ل",
		"غ",
		"س",
		"ك",
		"ب",
		"د"
	],
	"dayPeriods-format-wide-am": "ص",
	"dateFormatItem-y": "y G",
	"timeFormat-full": "h:mm:ss a zzzz",
	"months-standAlone-abbr": [
		"يناير",
		"فبراير",
		"مارس",
		"أبريل",
		"مايو",
		"يونيو",
		"يوليو",
		"أغسطس",
		"سبتمبر",
		"أكتوبر",
		"نوفمبر",
		"ديسمبر"
	],
	"dateFormatItem-Ed": "E، d",
	"dateFormatItem-yMMM": "MMM y G",
	"days-standAlone-narrow": [
		"ح",
		"ن",
		"ث",
		"ر",
		"خ",
		"ج",
		"س"
	],
	"eraAbbr": [
		"التقويم البوذي"
	],
	"dateFormatItem-yyyyMM": "MM‏/y G",
	"dateFormatItem-yyyyMMMM": "MMMM، y G",
	"dateFormat-long": "d MMMM، y G",
	"timeFormat-medium": "h:mm:ss a",
	"dateFormatItem-Hm": "HH:mm",
	"dateFormat-medium": "dd‏/MM‏/y G",
	"dateFormatItem-yMd": "d/‏M/‏y G",
	"dateFormatItem-yMMMM": "MMMM y G",
	"dateFormatItem-ms": "mm:ss",
	"quarters-standAlone-narrow": [
		"١",
		"٢",
		"٣",
		"٤"
	],
	"months-standAlone-wide": [
		"يناير",
		"فبراير",
		"مارس",
		"أبريل",
		"مايو",
		"يونيو",
		"يوليو",
		"أغسطس",
		"سبتمبر",
		"أكتوبر",
		"نوفمبر",
		"ديسمبر"
	],
	"dateFormatItem-MMMMEd": "E d MMMM",
	"dateFormatItem-MMMd": "d MMM",
	"quarters-format-narrow": [
		"١",
		"٢",
		"٣",
		"٤"
	],
	"timeFormat-long": "h:mm:ss a z",
	"months-format-abbr": [
		"يناير",
		"فبراير",
		"مارس",
		"أبريل",
		"مايو",
		"يونيو",
		"يوليو",
		"أغسطس",
		"سبتمبر",
		"أكتوبر",
		"نوفمبر",
		"ديسمبر"
	],
	"timeFormat-short": "h:mm a",
	"dateFormatItem-MMMMd": "d MMMM",
	"days-format-abbr": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	],
	"dateFormatItem-M": "L",
	"dateFormatItem-yMMMd": "d MMM، y G",
	"dateFormatItem-MEd": "E، d/M",
	"days-standAlone-short": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	],
	"days-standAlone-abbr": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	],
	"dateFormat-short": "d‏/M‏/y G",
	"dateFormatItem-yMMMEd": "E، d MMM، y G",
	"dateFormat-full": "EEEE، d MMMM، y G",
	"dateFormatItem-Md": "d/‏M",
	"dateFormatItem-yMEd": "E، d/‏M/‏y G",
	"months-format-wide": [
		"يناير",
		"فبراير",
		"مارس",
		"أبريل",
		"مايو",
		"يونيو",
		"يوليو",
		"أغسطس",
		"سبتمبر",
		"أكتوبر",
		"نوفمبر",
		"ديسمبر"
	],
	"days-format-short": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	],
	"dateFormatItem-d": "d",
	"quarters-format-wide": [
		"الربع الأول",
		"الربع الثاني",
		"الربع الثالث",
		"الربع الرابع"
	],
	"eraNarrow": [
		"التقويم البوذي"
	],
	"days-format-wide": [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	]
}
//end v1.x content
);